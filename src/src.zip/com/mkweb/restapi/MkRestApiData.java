package com.mkweb.restapi;

import com.mkweb.data.MkJsonData;

public class MkRestApiData extends MkJsonData{

}
