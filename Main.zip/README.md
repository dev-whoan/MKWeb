# MKweb
Minwhoan - Kihyeon's web repository

# Our Structure, Plan, Idea
<img src="https://user-images.githubusercontent.com/65178775/81583650-9b94b300-93ec-11ea-8683-c4ffc67215f9.png" width="66%" />

* Model

A server-side resources such as; DbAccessor, FileTransfer, Logger, ...

* Controller

A bridge of Model <---> Views

a. Config

Definition or settings of model's attributes, values, ...

b. Service

Management which excuted what View requested, serve the response of the task from Model to View.

* Views

Things, user will interact, see, ...

# To Do List

1. Define MkWeb's Functions

2. Schedule What To Do.
