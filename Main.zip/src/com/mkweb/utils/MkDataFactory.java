package com.mkweb.utils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

//Str -> Json ��ȯ�̶�
//Json -> Str

public class MkDataFactory {
	String stringData;
	JSONObject jsonObject;
	public MkDataFactory() {
		stringData = null;
		jsonObject = null;
	}
}