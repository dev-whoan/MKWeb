package com.mkweb.impl;

public interface XmlData {
	String getTag();
	String getControlName();
	void setControlName(String controlName);
	
	String getData();
	void setData(String data);
	
	String getMyInfo();
}